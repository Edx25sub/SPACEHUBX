from colorama import Fore, Style, init

init(autoreset=True)

print(Fore.MAGENTA + 'Esse app foi feito com o intuito educacional e não apoiamos atos terroristas, crimes, etc...')
print(Fore.MAGENTA + '-------------- Bem-vindo ao SPACEHUBX --------------')

print(Fore.MAGENTA + '  ______   _______    ______    ______   ________  __    __  __    __  _______   __    __ ')
print(Fore.MAGENTA + ' /      \\ /       \\  /      \\  /      \\ /        |/  |  /  |/  |  /  |/       \\ /  |  /  |')
print(Fore.MAGENTA + '/$$$$$$  |$$$$$$$  |/$$$$$$  |/$$$$$$  |$$$$$$$$/ $$ |  $$ |$$ |  $$ |$$$$$$$  |$$ |  $$ |')
print(Fore.MAGENTA + '$$ \\__$$/ $$ |__$$ |$$ |__$$ |$$ |  $$/ $$ |__    $$ |__$$ |$$ |  $$ |$$ |__$$ |$$  \\/$$/ ')
print(Fore.MAGENTA + '$$      \\ $$    $$/ $$    $$ |$$ |      $$    |   $$    $$ |$$ |  $$ |$$    $$<  $$  $$<  ')
print(Fore.MAGENTA + ' $$$$$$  |$$$$$$$/  $$$$$$$$ |$$ |   __ $$$$$/    $$$$$$$$ |$$ |  $$ |$$$$$$$  |  $$$$  \\ ')
print(Fore.MAGENTA + '/  \\__$$ |$$ |      $$ |  $$ |$$ \\__/  |$$ |_____ $$ |  $$ |$$ \\__$$ |$$ |__$$ | $$ /$$  |')
print(Fore.MAGENTA + '$$    $$/ $$ |      $$ |  $$ |$$    $$/ $$       |$$ |  $$ |$$    $$/ $$    $$/ $$ |  $$ |')
print(Fore.MAGENTA + ' $$$$$$/  $$/       $$/   $$/  $$$$$$/  $$$$$$$$/ $$/   $$/  $$$$$$/  $$$$$$$/  $$/   $$/ ')
print ('')
print(Fore.MAGENTA + 'Antes de começar, preciso de algumas informações básicas para o bom funcionamento do sistema:')
print(Fore.MAGENTA + 'O Bot não verificará as informações, digite-as certas.')
print ('')
nick = input(Fore.MAGENTA + 'Seu nick do discord: ')
webhook = input(Fore.MAGENTA + 'Seu webhook: ')
token = input(Fore.MAGENTA + 'Token do seu Bot: ')
id = input(Fore.MAGENTA + 'ID do seu servidor: ')
telefone = input(Fore.MAGENTA + '[Opcional, porém recomendado] Seu telefone para contato: ')
print("")
input(Fore.MAGENTA + 'Pressione Enter para prosseguir ao painel principal: ')
print(Fore.MAGENTA + '                ------------------------- Painel SPACEHUBX -------------------------')
print('')
print(Fore.MAGENTA + '[IL] Image Logger             [DG] Discord Grabber             [IG] IP Grabber           [LG] Link Grabber')
print(Fore.MAGENTA + '[CG] Cookie Grabber           [IF] Insta Fans                  [DM] Discord Members      [CCG] CC Grabber')
print(Fore.MAGENTA + '[WH] Wifi Hack                [PRC] PC Remote Control          [WH] WhatsApp Hack        [SH] Steam Hack')
print('')
tecla = input(Fore.MAGENTA + 'Escolha Sua Opção e Digite a Sigla Designada: ')

if tecla == 'IL':
    print(Fore.MAGENTA + 'Preparando Seu Image Logger, Aguarde a próxima tela...')
elif tecla == 'DG':
    print(Fore.MAGENTA + 'Preparando Discord Grabber, Aguarde a próxima tela...')
elif tecla == 'IG':
    print(Fore.MAGENTA + 'Preparando Seu IP Grabber, Aguarde a próxima tela...')
elif tecla == 'LG':
    print(Fore.MAGENTA + 'Preparando Seu Link Grabber, Aguarde a próxima tela...')
elif tecla == 'CG':
    print(Fore.MAGENTA + 'Preparando Seu Cookie Grabber, Aguarde a próxima tela...')
elif tecla == 'IF':
    print(Fore.MAGENTA + 'Preparando Seu Bot [Insta Fans], Aguarde a próxima tela...')
elif tecla == 'DM':
    print(Fore.MAGENTA + 'Preparando Seu Bot [Discord Members], Aguarde a próxima tela...')
elif tecla == 'CCG':
    print(Fore.MAGENTA + 'Preparando Seu Credit Card Grabber [CC], Aguarde a próxima tela...')
elif tecla == 'WH':
    print(Fore.MAGENTA + 'Preparando Seu Wifi Hack, Aguarde a próxima tela...')
elif tecla == 'PRC':
    print(Fore.MAGENTA + 'Preparando Seu PC Remote Control, Aguarde a próxima tela...')
elif tecla == 'SH':
    print(Fore.MAGENTA + 'Preparando Seu Steam Hack, Aguarde a próxima tela...')
